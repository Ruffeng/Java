package edu.uoc.dpoo;

public enum SubmissionStatus {
    PENDING,
    DONE,
    ERROR;
}
