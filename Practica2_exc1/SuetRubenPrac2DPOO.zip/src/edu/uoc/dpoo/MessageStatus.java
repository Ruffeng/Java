package edu.uoc.dpoo;

public enum MessageStatus {
    PENDING,
    READ;
}
