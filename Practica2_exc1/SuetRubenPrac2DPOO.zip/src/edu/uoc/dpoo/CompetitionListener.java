package edu.uoc.dpoo;

public interface CompetitionListener {
    public void onNewEvaluation();
    public void onCompetitionClosed();
}
